// 用户类型
export interface User {
  id: string;
  email: string;
  name: string;
  walletAddress: string;  // ETH 钱包地址
  hasPasskey: boolean;
  createdAt: string;     // 注册时间
}

// 联系人类型
export interface Contact {
  id: string;
  userId: string;        // 所属用户ID
  walletAddress: string;  // ETH 钱包地址
  name: string;          // 备注名
  createdAt: string;
}

// 转账记录类型
export interface Transfer {
  id: string;
  fromAddress: string;    // 发送方钱包地址
  toAddress: string;      // 接收方钱包地址
  amount: number;
  status: 'pending' | 'completed' | 'failed';
  description?: string;
  createdAt: string;
  txHash?: string;        // 交易哈希
}

// 登录方式
export type LoginMethod = 'email' | 'passkey';

// 注册表单数据
export interface RegisterFormData {
  email: string;
  name: string;
}

// 登录表单数据
export interface LoginFormData {
  email: string;
}

// 添加联系人表单数据
export interface ContactFormData {
  walletAddress: string;
  name: string;
}

// 转账表单数据
export interface TransferFormData {
  toAddress: string;
  amount: number;
  description?: string;
} 